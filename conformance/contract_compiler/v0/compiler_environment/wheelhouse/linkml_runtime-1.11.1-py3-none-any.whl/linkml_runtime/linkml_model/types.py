# Auto generated from types.yaml by pythongen.py version: 0.0.1
# Generation date: 2026-05-05T18:49:15
# Schema: types
#
# id: https://w3id.org/linkml/types
# description: Shared type definitions for the core LinkML mode and metamodel
# license: https://creativecommons.org/publicdomain/zero/1.0/


from linkml_runtime.utils.curienamespace import CurieNamespace
from linkml_runtime.utils.metamodelcore import (
    URI,
    Bool,
    Curie,
    Decimal,
    ElementIdentifier,
    NCName,
    NodeIdentifier,
    URIorCURIE,
    XSDDate,
    XSDDateTime,
    XSDTime,
)

metamodel_version = "1.7.0"
version = None

# Namespaces
LINKML = CurieNamespace("linkml", "https://w3id.org/linkml/")
SCHEMA = CurieNamespace("schema", "http://schema.org/")
SHEX = CurieNamespace("shex", "http://www.w3.org/ns/shex#")
XSD = CurieNamespace("xsd", "http://www.w3.org/2001/XMLSchema#")
DEFAULT_ = LINKML


# Types
class String(str):
    """A character string"""

    type_class_uri = XSD["string"]
    type_class_curie = "xsd:string"
    type_name = "string"
    type_model_uri = LINKML.String


class Integer(int):
    """An integer"""

    type_class_uri = XSD["integer"]
    type_class_curie = "xsd:integer"
    type_name = "integer"
    type_model_uri = LINKML.Integer


class Boolean(Bool):
    """A binary (true or false) value"""

    type_class_uri = XSD["boolean"]
    type_class_curie = "xsd:boolean"
    type_name = "boolean"
    type_model_uri = LINKML.Boolean


class Float(float):
    """A real number that conforms to the xsd:float specification"""

    type_class_uri = XSD["float"]
    type_class_curie = "xsd:float"
    type_name = "float"
    type_model_uri = LINKML.Float


class Double(float):
    """A real number that conforms to the xsd:double specification"""

    type_class_uri = XSD["double"]
    type_class_curie = "xsd:double"
    type_name = "double"
    type_model_uri = LINKML.Double


class Decimal(Decimal):
    """A real number with arbitrary precision that conforms to the xsd:decimal specification"""

    type_class_uri = XSD["decimal"]
    type_class_curie = "xsd:decimal"
    type_name = "decimal"
    type_model_uri = LINKML.Decimal


class Time(XSDTime):
    """A time object represents a (local) time of day, independent of any particular day"""

    type_class_uri = XSD["time"]
    type_class_curie = "xsd:time"
    type_name = "time"
    type_model_uri = LINKML.Time


class Date(XSDDate):
    """a date (year, month and day) in an idealized calendar"""

    type_class_uri = XSD["date"]
    type_class_curie = "xsd:date"
    type_name = "date"
    type_model_uri = LINKML.Date


class Datetime(XSDDateTime):
    """The combination of a date and time"""

    type_class_uri = XSD["dateTime"]
    type_class_curie = "xsd:dateTime"
    type_name = "datetime"
    type_model_uri = LINKML.Datetime


class DateOrDatetime(str):
    """Either a date or a datetime"""

    type_class_uri = LINKML["DateOrDatetime"]
    type_class_curie = "linkml:DateOrDatetime"
    type_name = "date_or_datetime"
    type_model_uri = LINKML.DateOrDatetime


class Uriorcurie(URIorCURIE):
    """a URI or a CURIE"""

    type_class_uri = XSD["anyURI"]
    type_class_curie = "xsd:anyURI"
    type_name = "uriorcurie"
    type_model_uri = LINKML.Uriorcurie


class Curie(Curie):
    """a compact URI"""

    type_class_uri = XSD["string"]
    type_class_curie = "xsd:string"
    type_name = "curie"
    type_model_uri = LINKML.Curie


class Uri(URI):
    """a complete URI"""

    type_class_uri = XSD["anyURI"]
    type_class_curie = "xsd:anyURI"
    type_name = "uri"
    type_model_uri = LINKML.Uri


class Ncname(NCName):
    """Prefix part of CURIE"""

    type_class_uri = XSD["string"]
    type_class_curie = "xsd:string"
    type_name = "ncname"
    type_model_uri = LINKML.Ncname


class Objectidentifier(ElementIdentifier):
    """A URI or CURIE that represents an object in the model."""

    type_class_uri = SHEX["iri"]
    type_class_curie = "shex:iri"
    type_name = "objectidentifier"
    type_model_uri = LINKML.Objectidentifier


class Nodeidentifier(NodeIdentifier):
    """A URI, CURIE or BNODE that represents a node in a model."""

    type_class_uri = SHEX["nonLiteral"]
    type_class_curie = "shex:nonLiteral"
    type_name = "nodeidentifier"
    type_model_uri = LINKML.Nodeidentifier


class Jsonpointer(str):
    """A string encoding a JSON Pointer. The value of the string MUST conform to JSON Point syntax and SHOULD dereference to a valid object within the current instance document when encoded in tree form."""

    type_class_uri = XSD["string"]
    type_class_curie = "xsd:string"
    type_name = "jsonpointer"
    type_model_uri = LINKML.Jsonpointer


class Jsonpath(str):
    """A string encoding a JSON Path. The value of the string MUST conform to JSON Point syntax and SHOULD dereference to zero or more valid objects within the current instance document when encoded in tree form."""

    type_class_uri = XSD["string"]
    type_class_curie = "xsd:string"
    type_name = "jsonpath"
    type_model_uri = LINKML.Jsonpath


class Sparqlpath(str):
    """A string encoding a SPARQL Property Path. The value of the string MUST conform to SPARQL syntax and SHOULD dereference to zero or more valid objects within the current instance document when encoded as RDF."""

    type_class_uri = XSD["string"]
    type_class_curie = "xsd:string"
    type_name = "sparqlpath"
    type_model_uri = LINKML.Sparqlpath


# Class references


# Enumerations


# Slots
class slots:
    pass
