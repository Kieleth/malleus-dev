import logging
import os
import pathlib
import sys
from typing import TYPE_CHECKING

import click
import yaml

from linkml._version import __version__
from linkml.generators.pythongen import PythonGenerator
from linkml.utils import datautils
from linkml.utils.datautils import (
    _get_context,
    _get_format,
    _is_xsv,
    dumpers_loaders,
    get_dumper,
    get_loader,
    infer_index_slot,
    infer_root_class,
)
from linkml.validator import validate as run_validation
from linkml_runtime.dumpers import json_dumper
from linkml_runtime.linkml_model import Prefix
from linkml_runtime.utils import inference_utils
from linkml_runtime.utils.compile_python import compile_python
from linkml_runtime.utils.inference_utils import infer_all_slot_values
from linkml_runtime.utils.schemaview import SchemaView

if TYPE_CHECKING:
    from linkml_runtime.utils.yamlutils import YAMLRoot

logger = logging.getLogger(__name__)


@click.command(name="convert")
@click.option("--module", "-m", help="Path to python datamodel module")
@click.option("--output", "-o", help="Path to output file")
@click.option(
    "--input-format",
    "-f",
    type=click.Choice(list(dumpers_loaders.keys())),
    help="Input format. Inferred from input suffix if not specified",
)
@click.option(
    "--output-format",
    "-t",
    type=click.Choice(list(dumpers_loaders.keys())),
    help="Output format. Inferred from output suffix if not specified",
)
@click.option(
    "--target-class",
    "-C",
    help="name of class in datamodel that the root node instantiates",
)
@click.option(
    "--target-class-from-path/--no-target-class-from-path",
    default=False,
    show_default=True,
    help="Infer the target class from the filename, should be ClassName-<other-chars>.{yaml,json,...}",
)
@click.option("--index-slot", "-S", help="top level slot. Required for CSV dumping/loading")
@click.option("--schema", "-s", help="Path to schema specified as LinkML yaml")
@click.option("--prefix", "-P", multiple=True, help="Prefixmap base=URI pairs")
@click.option("--prefix-file", help="Path to yaml file containing base=URI pairs")
@click.option(
    "--validate/--no-validate",
    default=True,
    show_default=True,
    help="Validate against the schema",
)
@click.option(
    "--infer/--no-infer",
    default=False,
    show_default=True,
    help="Infer missing slot values",
)
@click.option("--context", "-c", multiple=True, help="path to JSON-LD context file")
@click.option(
    "--list-wrapper",
    type=click.Choice(["square", "curly", "paren", "none"]),
    default=None,
    help="Wrapper style for multivalued fields in CSV/TSV: 'square' [a|b], 'curly' {a|b}, "
    "'paren' (a|b), 'none' a|b. Overrides schema annotation if set.",
)
@click.option(
    "--list-delimiter",
    default=None,
    help="Delimiter between list items in CSV/TSV (default: pipe character). Overrides schema annotation if set.",
)
@click.option(
    "--list-strip-whitespace/--no-list-strip-whitespace",
    default=None,
    help="Strip whitespace around list delimiters when loading and dumping CSV/TSV (default: strip). "
    "Overrides schema annotation if set.",
)
@click.option(
    "--refuse-delimiter-in-data/--no-refuse-delimiter-in-data",
    default=None,
    help="Raise an error if any multivalued field value contains the list delimiter character. "
    "Prevents silent data corruption during round-tripping. Overrides schema annotation if set.",
)
@click.option(
    "--boolean-output",
    type=click.Choice(["true", "True", "TRUE", "yes", "Yes", "YES", "on", "On", "ON", "1"]),
    default=None,
    help="How to write booleans in CSV/TSV output (default: true/false). "
    "Overrides the boolean_output schema annotation.",
)
@click.option(
    "--boolean-truthy",
    default=None,
    help="Additional truthy values to accept when loading booleans from CSV/TSV "
    "(comma-separated, e.g. 'yes,on,1'). Added to the defaults (T, TRUE) "
    "and any boolean_truthy schema annotation.",
)
@click.option(
    "--boolean-falsy",
    default=None,
    help="Additional falsy values to accept when loading booleans from CSV/TSV "
    "(comma-separated, e.g. 'no,off,0'). Added to the defaults (F, FALSE) "
    "and any boolean_falsy schema annotation.",
)
@click.version_option(__version__, "-V", "--version")
@click.argument("input")
def cli(
    input,
    module,
    target_class,
    context=None,
    output=None,
    input_format=None,
    output_format=None,
    prefix=None,
    prefix_file=None,
    target_class_from_path=None,
    schema=None,
    validate=None,
    infer=None,
    index_slot=None,
    list_wrapper=None,
    list_delimiter=None,
    list_strip_whitespace=None,
    refuse_delimiter_in_data=None,
    boolean_output=None,
    boolean_truthy=None,
    boolean_falsy=None,
) -> None:
    """
    Converts instance data to and from different LinkML Runtime serialization formats.

    The instance data must conform to a LinkML model, and either a path to a python
    module must be passed, or a path to a schema.

    The converter works by first using a linkml-runtime *loader* to
    instantiate in-memory model objects, then a *dumper* is used to serialize.
    A validation step is optionally performed in between

    When converting to or from RDF, a path to a schema must be provided.

    For more information, see https://linkml.io/linkml/data/index.html
    """
    if prefix and prefix_file is not None:
        raise Exception("Either set prefix OR prefix_file, not both.")
    if prefix is None:
        prefix = []
    if module is None:
        if schema is None:
            raise Exception("must pass one of module OR schema")
        else:
            python_module = PythonGenerator(schema).compile_module()
    else:
        python_module = compile_python(module)
    prefix_map = {}
    if prefix:
        for p in prefix:
            base, uri = p.split("=")
            prefix_map[base] = uri
    if prefix_file is not None:
        prefix_path = pathlib.Path(prefix_file).resolve()
        if not prefix_path.exists():
            raise Exception(f"Path {prefix_file} to prefix map does not exists.")
        with open(prefix_path) as prefix_stream:
            raw_prefix_map = yaml.safe_load(prefix_stream)
        prefix_file_map = raw_prefix_map.get("prefixes", None)
        if prefix_file_map is None:
            raise Exception("Provided prefix file does not contain the prefixes key.")
        prefix_map = prefix_file_map

    if schema is not None:
        sv = SchemaView(schema)
        if prefix_map:
            for k, v in prefix_map.items():
                sv.schema.prefixes[k] = Prefix(k, v)
                sv.set_modified()
    if target_class is None and target_class_from_path:
        target_class = os.path.basename(input).split("-")[0]
        logger.info(f"inferred target class = {target_class} from {input}")
    if target_class is None:
        target_class = infer_root_class(sv)
    if target_class is None:
        raise Exception("target class not specified and could not be inferred")
    py_target_class: YAMLRoot = python_module.__dict__[target_class]
    input_format = _get_format(input, input_format)
    loader = get_loader(input_format)

    inargs = {}
    outargs = {}
    if datautils._is_rdf_format(input_format):
        if sv is None:
            raise Exception("Must pass schema arg")
        inargs["schemaview"] = sv
        inargs["fmt"] = input_format
    if _is_xsv(input_format):
        if index_slot is None:
            index_slot = infer_index_slot(sv, target_class)
            if index_slot is None:
                raise Exception("--index-slot is required for CSV input")
        inargs["index_slot"] = index_slot
        inargs["schema"] = schema
        # Pass list formatting options (override schema annotations if set)
        if list_wrapper is not None:
            inargs["list_wrapper"] = list_wrapper
        if list_delimiter is not None:
            inargs["list_delimiter"] = list_delimiter
        if list_strip_whitespace is not None:
            inargs["list_strip_whitespace"] = list_strip_whitespace
        # refuse_delimiter_in_data only applies to dumping (output), not loading
        # Pass additional truthy/falsy values for loading
        if boolean_truthy is not None:
            inargs["boolean_truthy"] = frozenset(v.strip().lower() for v in boolean_truthy.split(",") if v.strip())
        if boolean_falsy is not None:
            inargs["boolean_falsy"] = frozenset(v.strip().lower() for v in boolean_falsy.split(",") if v.strip())
    obj = loader.load(source=input, target_class=py_target_class, **inargs)
    if infer:
        infer_config = inference_utils.Config(use_expressions=True, use_string_serialization=True)
        infer_all_slot_values(obj, schemaview=sv, config=infer_config)
    if validate:
        if schema is None:
            raise Exception("--schema must be passed in order to validate. Suppress with --no-validate")
        obj_dict = json_dumper.to_dict(obj)
        report = run_validation(obj_dict, schema, target_class)
        report.raise_for_results()

    output_format = _get_format(output, output_format, default="json")
    if output_format == "json-ld":
        if len(context) == 0:
            if schema is not None:
                context = [_get_context(schema)]
            else:
                raise Exception("Must pass in context OR schema for RDF output")
        outargs["contexts"] = list(context)
    if output_format == "rdf" or output_format == "ttl":
        if sv is None:
            raise Exception("Must pass schema arg")
        outargs["schemaview"] = sv
    if _is_xsv(output_format):
        if index_slot is None:
            index_slot = infer_index_slot(sv, target_class)
            if index_slot is None:
                raise Exception("--index-slot is required for CSV output")
        outargs["index_slot"] = index_slot
        outargs["schema"] = schema
        # Pass list formatting options (override schema annotations if set)
        if list_wrapper is not None:
            outargs["list_wrapper"] = list_wrapper
        if list_delimiter is not None:
            outargs["list_delimiter"] = list_delimiter
        if list_strip_whitespace is not None:
            outargs["list_strip_whitespace"] = list_strip_whitespace
        if refuse_delimiter_in_data is not None:
            outargs["refuse_delimiter_in_data"] = refuse_delimiter_in_data
        # Pass boolean output format (override schema annotation if set)
        if boolean_output is not None:
            outargs["boolean_output"] = boolean_output
    dumper = get_dumper(output_format)
    if output is not None:
        dumper.dump(obj, output, **outargs)
    else:
        print(dumper.dumps(obj, **outargs))


if __name__ == "__main__":
    cli(sys.argv[1:])
